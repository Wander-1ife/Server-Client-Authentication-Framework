import platform
import hashlib
import uuid
import psutil
import json
import subprocess
import pandas as pd

def get_system_info():
    system_info = {}
    system_info['platform'] = platform.system()  # OS
    system_info['platform_version'] = platform.version()  # OS Version
    system_info['platform_release'] = platform.release()  # OS Release
    system_info['architecture'] = platform.architecture()[0]  # Architecture (32bit/64bit)
    system_info['processor'] = platform.processor()  # Processor info
    system_info['machine'] = platform.machine()  # Machine type (e.g., x86_64)
    system_info['node'] = platform.node()  # Machine name (hostname)
    return system_info

def get_bios_uuid():
    """Retrieves the BIOS UUID on Windows using wmic."""
    try:
        bios_uuid = subprocess.check_output("wmic bios get serialnumber").decode().strip().split('\n')[1]
        return bios_uuid
    except Exception as e:
        return None  # Return None if the BIOS UUID cannot be retrieved

def get_motherboard_id():
    """Retrieves the Motherboard ID on Windows using wmic."""
    try:
        motherboard_id = subprocess.check_output("wmic baseboard get product").decode().strip().split('\n')[1]
        return motherboard_id
    except Exception as e:
        return None  # Return None if the motherboard ID cannot be retrieved

def get_wifi_mac_address():
    """Retrieves the MAC address of the Wi-Fi interface."""
    # Get all network interfaces and their information
    interfaces = psutil.net_if_addrs()

    # Iterate over each interface to find the Wi-Fi interface (usually 'Wi-Fi' or 'wlan' on Linux)
    for interface, addrs in interfaces.items():
        # Look for the Wi-Fi interface by its name (can vary by OS, for example 'Wi-Fi' on Windows or 'wlan0' on Linux)
        if 'Wi-Fi' in interface or 'wlan' in interface.lower():
            for addr in addrs:
                if addr.family == psutil.AF_LINK:  # Check if it's a MAC address
                    return addr.address
    return None  # Return None if no Wi-Fi interface found

def get_device_fingerprint():
    system_info = get_system_info()
    unique_string = json.dumps(system_info, sort_keys=True)  # Serialize system info into a string

    # Get MAC address of the Wi-Fi interface
    wifi_mac = get_wifi_mac_address()
    if wifi_mac:
        system_info['wifi_mac_address'] = wifi_mac
    else:
        system_info['wifi_mac_address'] = "Not available"

    # Get BIOS UUID and Motherboard ID, and add them to the system info
    bios_uuid = get_bios_uuid()
    motherboard_id = get_motherboard_id()
    
    if bios_uuid:
        system_info['bios_uuid'] = bios_uuid
    else:
        system_info['bios_uuid'] = "Not available"
    
    if motherboard_id:
        system_info['motherboard_id'] = motherboard_id
    else:
        system_info['motherboard_id'] = "Not available"

    # Combine all info and create a hash
    fingerprint = hashlib.sha256(unique_string.encode()).hexdigest()

    return fingerprint

def compare_fingerprint(username, device_fingerprint):
    # Hardcoded file path
    file_path = r"C:\Users\samia\OneDrive\Desktop\IS\DB.xlsx"  # Replace with the actual path to your Excel file
    
    # Load the Excel file
    df = pd.read_excel(file_path)
    
    # Check if the username exists in the dataframe
    if username in df['Username'].values:
        # Get the device fingerprint for the given username
        stored_fingerprint = df[df['Username'] == username]['Device Fingerprint'].values[0]
        
        # Compare the provided device fingerprint with the one in the file
        if stored_fingerprint == device_fingerprint:
            return "Device fingerprint matches."
        else:
            return "Device fingerprint does not match."
    else:
        return f"Username {username} not found in the Excel file."

# Get the device fingerprint and system information
fingerprint = get_device_fingerprint()

print("Device Fingerprint (SHA-256):", fingerprint)
result = compare_fingerprint('k224673@nu.edu.pk', fingerprint)
print(result)
