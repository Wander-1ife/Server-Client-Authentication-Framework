import requests

def get_geolocation():
    try:
        # Get the geolocation information based on IP using the ipinfo.io API
        response = requests.get('https://ipinfo.io')
        # Check if the request was successful
        response.raise_for_status()
        
        # Parse the JSON response
        data = response.json()
        
        # Extract relevant details
        ip = data.get('ip', 'Unknown IP')
        location = f"{data.get('city', 'Unknown City')}, {data.get('region', 'Unknown Region')}, {data.get('country', 'Unknown Country')}"
        #loc = data.get('loc', 'Unknown Location').split(',')
        
        # Print the geolocation information
        print(f"IP Address: {ip}")
        print(f"Location: {location}")
    
    except requests.exceptions.RequestException as e:
        # Handle exceptions (e.g., network issues, invalid API request)
        print(f"Error: {e}")

# Call the function to get and display the geolocation
get_geolocation()
