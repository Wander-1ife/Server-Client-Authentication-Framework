import socket
import joblib
import pandas as pd
import uuid
import os
from datetime import datetime
import ssl
import smtplib
import csv
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

model = joblib.load(r"phishing_url_model.pkl")#ADD YOUR OWN PATH
file_path =r"DB.xlsx"#ADD YOUR OWN PATH
LOG_FILE = r"logs.csv"#ADD YOUR OWN PATH
TOKEN_FILE = "generated_tokens.txt"

#Email Generation to the user
def send_email(receiver_email, device_details, login_time,geolocation):
    sender_email = ""  # Your email
    sender_password = ""  # Your password
    smtp_server = "smtp.gmail.com"
    smtp_port = 465

    # Subject and email body
    subject = "Login Attempts!! Was this you.."
    html = f"""
    <html>
    <head>
        <title>Login Attempt Notification</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
        <div>
            <p><b>Dear User,</b></p>
            <p>Your account was logged into from the following device in {geolocation}</p>
            <p><b>Device Details:</b> {device_details}<br>
               <b>Login Time:</b> {login_time}</p>
            <p>If this was you, no further action is required. If this was not you, please secure your account immediately.</p>
            <p>Best regards,<br>
               Security Team</p>
        </div>
    </body>
    </html>
    """

    # Create the email
    msg = MIMEMultipart()
    msg["Subject"] = subject
    msg["From"] = sender_email
    msg["To"] = receiver_email
    msg.attach(MIMEText(html, "html"))

    # Send the email
    context = ssl.create_default_context()
    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port, context=context) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver_email, msg.as_string())
        print(f"Email sent to {receiver_email}")
    except Exception as e:
        print(f"Error sending email to {receiver_email}: {e}")

# Feature extraction function (same as used in training)
def extract_features(url):
    features = {}
    
    # URL length
    features['url_length'] = len(url)
    
    # Count the number of dots in the URL
    features['num_dots'] = url.count('.')
    
    # Check if the URL contains suspicious keywords
    suspicious_keywords = ["login.secure, verify-login, loginaccount,secure-account, secure-login, securebanking, verify-identity, online-banking, helpdesk, support-portal"]
    features['num_suspicious_keywords'] = sum(1 for word in suspicious_keywords if word in url.lower())
    
    # Check for HTTPS (legitimate URLs are more likely to use HTTPS)
    features['has_http'] = 1 if url.lower().startswith('http://') else 0
    
    return features

# Function to make predictions
def predict_url(url):
    
    features = extract_features(url)
    features_df = pd.DataFrame([features])  # Convert to DataFrame
    prediction = model.predict(features_df)
    
    # Return the prediction
    return "Legitimate" if prediction == 1 else "Phishing"

#Check for correct credentials
def login(username, password,file_path):
    # Load the Excel file
    df = pd.read_excel(file_path)
    
    # Convert 'Username' and 'Password' columns to strings to avoid type mismatches
    df['Username'] = df['Username'].astype(str).str.strip()
    df['Password'] = df['Password'].astype(str).str.strip()

    # Check if the username exists in the file
    user_record = df[df['Username'] == username]
    
    if not user_record.empty:
        # If user found, check if password matches
        if user_record.iloc[0]['Password'] == password:
            return '1'  # Login successful
        else:
            return '0'  # Incorrect password
    else:
        return '0'  # Username not found

#Session Token Uniqueness checked
def load_generated_tokens():
    # Check if the token file exists, and load existing tokens
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, 'r') as file:
            # Read all tokens from the file and return as a set
            return set(file.read().splitlines())
    return set()

#Session Token saved
def save_token(token):
    # Append the new token to the file
    with open(TOKEN_FILE, 'a') as file:
        file.write(token + "\n")

#Session Token generated
def generate_unique_token():
    generated_tokens = load_generated_tokens()

    while True:
        # Generate a random unique token
        token = str(uuid.uuid4())
        # Check if the token has already been generated
        if token not in generated_tokens:
            # Save the new token to the file
            save_token(token)
            return token

#User allowed time gathering
def load_allowed_times(file_path):
    df = pd.read_excel(file_path)
    allowed_times = {}
    for _, row in df.iterrows():
        username = row['Username']
        start_time = row['start time']  # Directly use the value if it's already datetime.time
        end_time = row['end time']      # Directly use the value if it's already datetime.time
        allowed_times[username] = (start_time, end_time)
    return allowed_times

# Function to check if a login falls within the allowed time window
def is_within_login_window(login_time, start_time, end_time):
    return start_time <= login_time <= end_time

# Simulate a login attempt
def log_login_attempt(user, allowed_times):
    current_time = datetime.now().time()
    if user in allowed_times:
        start_time, end_time = allowed_times[user]
        if is_within_login_window(current_time, start_time, end_time):
            print(f"Login allowed for user {user} at {current_time}.")
            return 1
        else:
            return 0

#device checking
def compare_fingerprint(username, device_fingerprint,file_path):
    # Load the Excel file
    df = pd.read_excel(file_path)
    
    # Check if the username exists in the dataframe
    if username in df['Username'].values:
        # Get the device fingerprint for the given username
        stored_fingerprint = df[df['Username'] == username]['Device Fingerprint'].values[0]
        
        # Compare the provided device fingerprint with the one in the file
        if stored_fingerprint == device_fingerprint:
            print("Device fingerprint matches.")
        else:
            print("Device fingerprint does not match.")
            return 0

#Location checking
def compare_location(username, geolocation,file_path):    
    # Load the Excel file
    df = pd.read_excel(file_path)
    
    # Check if the username exists in the dataframe
    if username in df['Username'].values:
        # Get the device fingerprint for the given username
        stored_location = df[df['Username'] == username]['Location'].values[0]
        
        # Compare the provided device fingerprint with the one in the file
        if stored_location == geolocation:
            print("Device Location matches.")
        else:
            print("Device Location does not match.")
            return 0

#Log Maintaining
def log_authentication_attempt(username, password, timestamp, location, device_info, result, details):
    # Ensure the log file exists or create it with a header
    file_exists = os.path.isfile(LOG_FILE)

    with open(LOG_FILE, mode='a', newline='') as file:
        writer = csv.writer(file)
        
        # Write the header only if the file is being created for the first time
        if not file_exists:
            writer.writerow([
                "Timestamp", 
                "Location", 
                "Device Info", 
                "Inputted Username", 
                "Result", 
                "Inputted Password", 
                "Details"
            ])
        
        # Write the log entry
        writer.writerow([
            timestamp, 
            location, 
            device_info, 
            username, 
            result, 
            password, 
            details
        ])

def start_server(host='0.0.0.0', port=8000):
    try:
        print(f"Server started listening...")
        # Create a socket object
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        # Bind the socket to the host and port
        server_socket.bind((host, port))

        # Listen for incoming connections
        server_socket.listen(1)  # Only one connection at a time

        while True:
            try:
                # Accept a connection from a client
                client_socket, client_address = server_socket.accept()
                print(f"Connection established with {client_address}")

                # Handle client communication
                while True:
                    # Receive data from the client
                    data = client_socket.recv(1024).decode().strip()
                    if not data:
                        print(f"Connection closed by {client_address}")
                        break  # Break out of the inner while loop to listen for new connections
                    else:
                        result = predict_url(data)
                        reply = f"The URL '{data}' is classified as: {result}"
                        print(reply)
                        client_socket.sendall(result.encode())

                        if result == "Legitimate":
                            unique_token = generate_unique_token()
                            print(f"Generated Unique Token: {unique_token}")
                            client_socket.sendall(unique_token.encode())
                            attempts=3
                            for _ in range (attempts):
                                username = client_socket.recv(1024).decode()
                                password = client_socket.recv(1024).decode()
                                login_result = login(username, password,file_path)
                                client_socket.sendall(login_result.encode())
                                device_info = client_socket.recv(1024).decode()                            
                                device_fingerprint = client_socket.recv(1024).decode()
                                geolocation = client_socket.recv(1024).decode()
                                current_time = datetime.now()
                                if login_result == "1":
                                    print(f"'{username}' successfully logged in...")
                                    fingerprint_result = compare_fingerprint(username, device_fingerprint,file_path)
                                    geolocation_result = compare_location(username, geolocation,file_path)
                                    allowed_times = load_allowed_times(file_path)
                                    time_result = log_login_attempt(username, allowed_times)

                                    # Check for suspicious activity
                                    suspicious_activity = []
                                    if time_result == 0:
                                        suspicious_activity.append("Login outside allowed time window")
                                    if fingerprint_result == 0:
                                        suspicious_activity.append("Device fingerprint mismatch")
                                    if geolocation_result == 0:
                                        suspicious_activity.append("Location mismatch")

                                    if suspicious_activity:
                                        # Log suspicious activity
                                        log_authentication_attempt(
                                            username=username,
                                            password=password,
                                            timestamp=current_time,
                                            location=geolocation,
                                            device_info=device_info,
                                            result="Success",
                                            details="; ".join(suspicious_activity)
                                        )
                                        # Send email notification
                                        send_email(username, device_info, current_time, geolocation)
                                    else:
                                        # Log successful login
                                        log_authentication_attempt(
                                            username=username,
                                            password=password,
                                            timestamp=current_time,
                                            location=geolocation,
                                            device_info=device_info,
                                            result="Success",
                                            details="No issues detected"
                                        )
                                else:
                                    print(f"'{username}' faced an error while logging in with password: '{password}'...")
                                    log_authentication_attempt(
                                        username=username,
                                        password=password,
                                        timestamp=current_time,
                                        location=geolocation,
                                        device_info=device_info,
                                        result="Failed",
                                        details="Incorrect username or password"
                                    )
                # Close the client connection once the client disconnects or sends no data
                client_socket.close()

            except Exception as e:
                print(f"Error while handling client: {e}")
                continue  # Continue listening for new client connections

    except KeyboardInterrupt:
        print("\nServer shutting down.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        server_socket.close()


if __name__ == '__main__':
    # Start the server
    start_server()
