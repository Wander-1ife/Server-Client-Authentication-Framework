import socket
import platform
import hashlib
import uuid
import psutil
import json
import subprocess
import requests
import getpass

#Device fingerprint info gathering
def get_system_info():
    system_info = {}
    system_info['platform'] = platform.system()  # OS
    system_info['platform_version'] = platform.version()  # OS Version
    system_info['platform_release'] = platform.release()  # OS Release
    system_info['architecture'] = platform.architecture()[0]  # Architecture (32bit/64bit)
    system_info['processor'] = platform.processor()  # Processor info
    system_info['machine'] = platform.machine()  # Machine type (e.g., x86_64)
    system_info['node'] = platform.node()  # Machine name (hostname)
    return system_info

def get_bios_uuid():
    """Retrieves the BIOS UUID on Windows using wmic."""
    try:
        bios_uuid = subprocess.check_output("wmic bios get serialnumber").decode().strip().split('\n')[1]
        return bios_uuid
    except Exception as e:
        return None  # Return None if the BIOS UUID cannot be retrieved

def get_motherboard_id():
    """Retrieves the Motherboard ID on Windows using wmic."""
    try:
        motherboard_id = subprocess.check_output("wmic baseboard get product").decode().strip().split('\n')[1]
        return motherboard_id
    except Exception as e:
        return None  # Return None if the motherboard ID cannot be retrieved

def get_wifi_mac_address():
    """Retrieves the MAC address of the Wi-Fi interface."""
    # Get all network interfaces and their information
    interfaces = psutil.net_if_addrs()

    # Iterate over each interface to find the Wi-Fi interface (usually 'Wi-Fi' or 'wlan' on Linux)
    for interface, addrs in interfaces.items():
        # Look for the Wi-Fi interface by its name (can vary by OS, for example 'Wi-Fi' on Windows or 'wlan0' on Linux)
        if 'Wi-Fi' in interface or 'wlan' in interface.lower():
            for addr in addrs:
                if addr.family == psutil.AF_LINK:  # Check if it's a MAC address
                    return addr.address
    return None  # Return None if no Wi-Fi interface found

def get_device_fingerprint():
    system_info = get_system_info()
    unique_string = json.dumps(system_info, sort_keys=True)  # Serialize system info into a string

    # Get MAC address of the Wi-Fi interface
    wifi_mac = get_wifi_mac_address()
    if wifi_mac:
        system_info['wifi_mac_address'] = wifi_mac
    else:
        system_info['wifi_mac_address'] = "Not available"

    # Get BIOS UUID and Motherboard ID, and add them to the system info
    bios_uuid = get_bios_uuid()
    motherboard_id = get_motherboard_id()
    
    if bios_uuid:
        system_info['bios_uuid'] = bios_uuid
    else:
        system_info['bios_uuid'] = "Not available"
    
    if motherboard_id:
        system_info['motherboard_id'] = motherboard_id
    else:
        system_info['motherboard_id'] = "Not available"

    # Combine all info and create a hash
    fingerprint = hashlib.sha256(unique_string.encode()).hexdigest()

    return fingerprint

#Device Location gathering
def get_geolocation():
    try:
        # Get the geolocation information based on IP using the ipinfo.io API
        response = requests.get('https://ipinfo.io')
        # Check if the request was successful
        response.raise_for_status()
        
        # Parse the JSON response
        data = response.json()
        # Extract relevant details
        location = f"{data.get('city', 'Unknown City')}, {data.get('region', 'Unknown Region')}, {data.get('country', 'Unknown Country')}"
        return location
    
    except requests.exceptions.RequestException as e:
        # Handle exceptions (e.g., network issues, invalid API request)
        print(f"Error: {e}")

#Device info gathering
def get_os_info():
    # Get OS details
    os_info = {
        "OS": platform.system(),
        "OS Version": platform.version(),
        "OS Release": platform.release(),
        "Processor": platform.processor(),
        "Node": platform.node(),
    }
    
    # Create a formatted string with the OS information
    info_string = "\n".join([f"{key}: {value}" for key, value in os_info.items()])
    
    return info_string

def start_client():
    flag=1
    # The server IP address and port are fixed
    host = input("Enter the server IP address: ")  # User can enter IP address
    port = 8000  # Fixed port

    try:
        # Create a socket object
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # Connect to the server
        client_socket.connect((host, port))
        print(f"Connected to server at {host}")
        while flag==1:
            # Get input from the user
            message = input("Enter URL: ")
            
            # Send the message to the server
            client_socket.sendall(message.encode())

            # Receive the server's reply
            reply = client_socket.recv(1024).decode()
            urlresult = f"The URL '{message}' is classified as: {reply}"
            print(urlresult)
            if reply=='Legitimate':
                uniquetoken=client_socket.recv(1024).decode()
                print(f"Generated Unique Token: {uniquetoken}")
                useruniquetoken=input("Enter Token: ")
                if useruniquetoken==uniquetoken:
                    attempts = 3  # Allow the user 3 attempts
                    for _ in range(attempts):
                        # Ask for username and password input
                        username = input("Username: ").strip()
                        password = getpass.getpass("Password: ").strip()
                        client_socket.sendall(username.encode())
                        client_socket.sendall(password.encode())
                        result=client_socket.recv(1024).decode()
                        device_info=get_os_info()
                        client_socket.sendall(device_info.encode())
                        fingerprint = get_device_fingerprint()
                        client_socket.sendall(fingerprint.encode())
                        geolocation=get_geolocation()
                        client_socket.sendall(geolocation.encode())
                        # Check login result
                        
                        if result == '1':
                            print("Login successful!")
                            flag=0
                            break  # Exit the loop if login is successful
                        else:
                            print("Username or password is incorrect. Please try again.")
                    else:
                        print("You have exceeded the maximum number of login attempts.")
                        break
                else:
                    print("Wrong Session Token....")
                    break

        # Close the connection
        client_socket.close()
        print("Connection closed.")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    # Start the client
    start_client()